# Função para ver que se um número é inteiro ou não
def leiaInt(msg):
    while True:
        try:
            n = int(input(msg))
        except (ValueError, TypeError):
            print(' ERRO: por favor, digite a opção válida. ')
            continue
        except KeyboardInterrupt:
            print(' Usuário preferiou não digitar a opção. ')
            return 0
        else:
            return n

# Função que retorna uma linha com um tamanho de 42
def linha(tam=42):
    return '-'*tam

# Função que cria um cabeçalho
def cabecalho(txt):
    print(linha())
    print(txt.center(42))
    print(linha())

# Função que exibi um menu com a funcionalidade opção com a função de ler um número inteiro.
def exibirMenu(lista):
    cabecalho('Sistema de Tarefas ')
    c=1
    for item in lista:
        print(f'{c} - {item}')
        c+=1
    print(linha())
    opcao=leiaInt('Sua Opção: ')
    return opcao